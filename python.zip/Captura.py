nombre =input ("Por favor, digite su nombre")
apellidos =input ("Por favor, digite sus apellidos")

print ("Hola, bienvenido" , nombre," ", apellidos)