nota=float(input("Ingresa una nota entre 0 y 100:"))
if nota >=90:
    print("Su calificacion es excelente")
elif nota>=70:
    print("Su calificacion es buena")
elif nota>=60:
    print("Su calificacion es suficiente")
else:
    print("Su calificacion es insuficiente")
