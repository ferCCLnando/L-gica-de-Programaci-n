Angela=True
Camilo=False
Fiesta= Angela and Camilo

print("El resultado del operador and" ,Fiesta)

Fiesta= Angela or Camilo
print("El resultado del operador or" ,Fiesta)